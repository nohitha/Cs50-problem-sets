// pre defined libraries
# include <stdio.h>
# include <cs50.h>
# include <math.h>

int main(void)// main function
{
    float dollars, cents;
    int coins = 0;
    do
    {
        dollars = get_float("Change owed: "); // taking user input
    }
    while (dollars <= 0); // to prompt user for only positive values
    cents = round(dollars * 100);// dollors to cents conversion and round off
    for (int i = 0; cents != 0; i++) // to repeat untill cents is 0
    {
        if (cents >= 25)
        {
            cents = cents - 25;
            coins++;
        }
        else if (cents >= 10 && cents < 25)
        {
            cents = cents - 10;
            coins++;
        }
        else if (cents >= 5 && cents < 10)
        {
            cents = cents - 5;
            coins++;
        }
        else
        {
            cents = cents - 1;
            coins++;
        }
    }
    printf("%i \n", coins);
    return 0;
}