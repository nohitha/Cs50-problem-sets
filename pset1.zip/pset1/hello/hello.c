//Pre defined library files
# include <stdio.h>
# include <cs50.h>

//main function
int main(void)
{
    string name = get_string("What's your name\n");//asks for your name
    printf("hello, %s\n", name);// print hello joined with name
}