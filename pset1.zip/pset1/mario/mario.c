//pre-defined libraries
# include <stdio.h>
# include <cs50.h>

int main(void)// main function
{
    int height;
    do
    {
        height = get_int("Height: ");
    }
    while (height <= 0 || height >= 9); //do while for prompting the user if input is not between 1 and 8.
    for (int i = 0; i < height; i++) //no of columns
    {
        int j = height - 1;
        for (j = (height - 1); j >= 0; j--) //no. of rows
        {
            if (j <= i)
            {
                printf("#");
            }
            else
            {
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}


